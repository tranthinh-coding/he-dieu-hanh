module.exports = {
  mode: "jit",
  content: ["./src/**/*.vue", "./public/index.html"],
  theme: {
    extend: {},
  },
  plugins: [],
};
