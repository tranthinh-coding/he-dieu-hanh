<template>
  <nav>
    <router-link to="/">FCFS</router-link> |
    <router-link to="/sjf-non-priority">sjf non ưu tiên</router-link> |
    <router-link to="/sjf-priority">sjf ưu tiên</router-link> |
    <router-link to="/do-uu-tien">Độ ưu tiên</router-link> |
    <router-link to="/round-robin">Round Robin</router-link>
  </nav>
</template>
