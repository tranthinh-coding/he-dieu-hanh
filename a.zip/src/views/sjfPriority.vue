<script setup>
import { ref } from "vue";
import _ from "lodash";

import TheGant from "@/components/TheGant.vue";
import TheTimer from "@/components/TheTimer.vue";

const ps = ref([]);
const timer = ref([]);
const gant = ref([]);
const tavg = ref(0);

reset();

function addMoreNumber() {
  ps.value.length = ps.value.length + 1;
  ps.value[ps.value.length - 1] = {
    p: `P${ps.value.length}`,
    timeUse: null,
    timeSpendding: null,
    status: false,
  };
}

function reset() {
  ps.value = [{ 
    p: "P1", 
    timeUse: null, 
    timeSpendding: null, 
    status: false,
  }];
  tavg.value = 0;
  gant.value = [];
  timer.value = [];
}

function resetStatus() {
  ps.value.forEach((e) => (e.status = false));
}

// function makeTimer() {
//   timer.value = gant.value.map((e) => {
//     return {
//       t: `T${e.p[1]}`,
//       spendding: e.end - (e.end - e.start) - e.timeSpend,
//     };
//   });
//   timer.value.sort((a, b) => a.t - b.t);
// }

// function makeAllTimeSpendding() {
//   const allTimeSpendding = timer.value.reduce(
//     (pre, curr) => pre + curr.spendding,
//     0
//   );
//   tavg.value = allTimeSpendding / timer.value.length || 0;
// }

// lay ra pi da san sang chay va thoi gian thuc thi nho nhat
function getPiCanRunAndTimeUseMin(psFake, time, currentP) {
  let minP = _.cloneDeep(currentP);
  for (const pi of psFake) {
    if (!pi.status && pi.timeSpendding <= time && pi.timeUse < minP.timeUse) {
      minP = pi;
    }
  }
  if (minP.status) return false;
  return minP;
}



// function getAllTimeUse() {
//   return ps.value.reduce((prev, curr) => {
//     return prev + curr.timeUse
//   }, 0);
// }

function makeGantTime(psFake) {
  let time = 0;
  gant.value = [];
  let currRun = psFake[0];

  let t = true;
  while (t) {
    const pCanRun = getPiCanRunAndTimeUseMin(psFake, time, currRun);
    if (pCanRun == false) {
      console.log(pCanRun, currRun);
      break;
    }
    --pCanRun.timeUse;
    if (pCanRun.p == currRun.p && gant.value.length != 0) {
      gant.value[gant.value.length - 1].end += 1;
    } else {
      gant.value.push({
        p: pCanRun.p,
        start: time, 
        end: time + 1 
      });
      currRun = pCanRun;
    }
    if (pCanRun.timeUse == 0) pCanRun.status = true; // done Pi
    descrementTimeP();
    ++time;
  }

  // giam thoi gian doi cua tat ca
  function descrementTimeP() {
    psFake.forEach((e) => {
      if (e.timeSpendding > 0)
        --e.timeSpendding;
    })
  }
}

function calculator() {
  resetStatus();
  
  const psFake = _.cloneDeep(ps.value);

  psFake.sort((a, b) => a.timeSpendding - b.timeSpendding);

  // const totalTimeUse = ps.value.reduce((prev, curr) => prev + curr.timeUse, 0);

  makeGantTime(psFake);

  // console.log({ gant });

  return;

  // makeTimer();

  // makeAllTimeSpendding();
}

function removeItem(index) {
  ps.value.splice(index, 1);
}

</script>

<template>
  <div class="container">
    <div class="rounded-2xl bg-slate-50 p-4">
      <button
        class="text-slate-50 mr-2 px-16 py-2 bg-blue-600 rounded-xl"
        @click="addMoreNumber"
      >
        Thêm
      </button>
      <button
        class="text-slate-50 ml-2 px-16 py-2 bg-blue-600 rounded-xl"
        @click="reset"
      >
        Reset
      </button>
      <div class="flex mt-5 justify-center gap-10 items-center">
        <p>Time xài</p>
        <p>Time nạp</p>
      </div>
      <div v-for="(p, i) in ps" :key="i">
        <div class="my-2 flex items-center justify-center gap-2">
          <p>{{ p.p }}</p>
          <input
            class="px-2 py-1 border border-slate-500 rounded"
            type="number"
            v-model="p.timeUse"
          />
          <input
            class="px-2 py-1 border border-slate-500 rounded"
            type="number"
            v-model="p.timeSpendding"
          />
          <button
            @click="removeItem(i)"
            class="text-slate-50 px-3 py-1 bg-blue-600 rounded-xl"
          >
            X
          </button>
        </div>
      </div>
      <!--  -->
      <div>
        <button
          @click="calculator"
          class="text-slate-50 px-16 py-2 bg-blue-600 rounded-xl"
        >
          Tính
        </button>
      </div>
    </div>

    <the-timer :timer="timer" :tavg="tavg" />

    <the-gant :gant="gant" />
  </div>
</template>
